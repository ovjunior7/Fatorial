
package aula10_exemplo1;

/**
 *
 * @author Osvaldo Viana Jr
 */
public class Aula10_Exemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        System.out.println("executando thread main");
        Thread.sleep(5000);
    }    
}
